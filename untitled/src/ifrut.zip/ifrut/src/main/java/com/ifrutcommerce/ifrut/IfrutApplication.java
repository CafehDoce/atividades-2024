package com.ifrutcommerce.ifrut;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IfrutApplication {

	public static void main(String[] args) {
		SpringApplication.run(IfrutApplication.class, args);
	}

}
