package com.ifrutcommerce.ifrut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IfrutApplicationTests {

	@Test
	void contextLoads() {
	}

}
